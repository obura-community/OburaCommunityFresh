package ke.obura.community;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.*;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private EditText nameInput, phoneInput, codeInput;
    private Button sendButton, verifyButton;
    private TextView status;
    private String verificationId;
    private PhoneAuthProvider.ForceResendingToken resendToken;
    private FirebaseAuth auth;
    private FirebaseFirestore db;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupFirebase();
        showLogin();
    }

    private void setupFirebase() {
        try {
            FirebaseOptions options = new FirebaseOptions.Builder()
                .setApiKey(getString(R.string.firebase_api_key))
                .setApplicationId(getString(R.string.firebase_application_id))
                .setProjectId(getString(R.string.firebase_project_id))
                .setGcmSenderId(getString(R.string.firebase_sender_id))
                .setStorageBucket(getString(R.string.firebase_storage_bucket))
                .build();
            if (FirebaseApp.getApps(this).isEmpty()) FirebaseApp.initializeApp(this, options);
            auth = FirebaseAuth.getInstance();
            db = FirebaseFirestore.getInstance();
        } catch (Exception e) { auth = null; }
    }

    private void showLogin() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(28, 42, 28, 28);
        root.setBackgroundColor(Color.rgb(245,248,246));

        TextView title = new TextView(this);
        title.setText("OBURA COMMUNITY APP");
        title.setTextSize(24); title.setTextColor(Color.rgb(5,85,64));
        title.setGravity(Gravity.CENTER); title.setTypeface(null, 1);
        root.addView(title, matchWrap());

        TextView sub = new TextView(this);
        sub.setText("MCA  •  Obura Philip Were");
        sub.setTextSize(15); sub.setTextColor(Color.DKGRAY);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub, matchWrap());

        nameInput = field("Your full name", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        phoneInput = field("Phone number e.g. +2547XXXXXXXX", InputType.TYPE_CLASS_PHONE);
        codeInput = field("SMS verification code", InputType.TYPE_CLASS_NUMBER);
        codeInput.setVisibility(View.GONE);
        root.addView(nameInput, matchWrap()); root.addView(phoneInput, matchWrap()); root.addView(codeInput, matchWrap());

        sendButton = new Button(this); sendButton.setText("SEND VERIFICATION CODE");
        verifyButton = new Button(this); verifyButton.setText("VERIFY & REGISTER"); verifyButton.setVisibility(View.GONE);
        status = new TextView(this); status.setTextColor(Color.DKGRAY); status.setPadding(4,20,4,12);
        root.addView(sendButton, matchWrap()); root.addView(verifyButton, matchWrap()); root.addView(status, matchWrap());
        sendButton.setOnClickListener(v -> sendCode());
        verifyButton.setOnClickListener(v -> verifyCode());
        setContentView(root);
        if (auth == null) status.setText("Firebase setup is required before registration can work.");
    }

    private EditText field(String hint, int type) {
        EditText e = new EditText(this); e.setHint(hint); e.setInputType(type);
        e.setSingleLine(true); e.setPadding(18,12,18,12); return e;
    }
    private LinearLayout.LayoutParams matchWrap() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 12, 0, 8); return p;
    }

    private void sendCode() {
        String name = nameInput.getText().toString().trim();
        String phone = phoneInput.getText().toString().trim();
        if (name.isEmpty() || phone.isEmpty()) { status.setText("Enter your name and phone number first."); return; }
        if (auth == null) { status.setText("Firebase is not configured yet."); return; }
        sendButton.setEnabled(false);
        status.setText("Requesting SMS verification...");
        PhoneAuthOptions options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phone).setTimeout(60L, TimeUnit.SECONDS).setActivity(this)
            .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                @Override public void onVerificationCompleted(PhoneAuthCredential credential) {
                    signIn(credential);
                }
                @Override public void onVerificationFailed(FirebaseException e) {
                    sendButton.setEnabled(true); status.setText("Verification failed: " + e.getLocalizedMessage());
                }
                @Override public void onCodeSent(String id, PhoneAuthProvider.ForceResendingToken token) {
                    verificationId = id; resendToken = token;
                    codeInput.setVisibility(View.VISIBLE); verifyButton.setVisibility(View.VISIBLE);
                    sendButton.setEnabled(true); status.setText("Code sent. Enter the SMS code.");
                }
            }).build();
        PhoneAuthProvider.verifyPhoneNumber(options);
    }

    private void verifyCode() {
        String code = codeInput.getText().toString().trim();
        if (verificationId == null || code.isEmpty()) { status.setText("Enter the SMS code."); return; }
        signIn(PhoneAuthProvider.getCredential(verificationId, code));
    }

    private void signIn(PhoneAuthCredential credential) {
        auth.signInWithCredential(credential).addOnCompleteListener(this, task -> {
            if (!task.isSuccessful()) { status.setText("Code verification failed. Try again."); return; }
            FirebaseUser user = auth.getCurrentUser();
            if (user == null) { status.setText("Could not confirm account."); return; }
            java.util.Map<String,Object> profile = new java.util.HashMap<>();
            profile.put("uid", user.getUid());
            profile.put("name", nameInput.getText().toString().trim());
            profile.put("phone", user.getPhoneNumber());
            profile.put("phoneVerified", user.getPhoneNumber() != null);
            profile.put("createdAt", com.google.firebase.firestore.FieldValue.serverTimestamp());
            db.collection("users").document(user.getUid()).set(profile)
                .addOnSuccessListener(x -> status.setText("Phone verified. Your member profile is registered."))
                .addOnFailureListener(e -> status.setText("Verified, but profile save failed: " + e.getLocalizedMessage()));
        });
    }
}
